# World Awakened Documentation Map and Update Contract

Documentation index, read-order contract, and cross-update policy for all repository markdown docs.

- Document status: Active governance index
- Last updated: 2026-03-12
- Scope: Required documentation intake, cross-references, and currency rules

---

## 0. Purpose

This file defines:
- which docs must be read before implementation work
- how docs reference each other
- which docs must be updated together when contracts change
- the standard format expected for shared reference docs

Use this as the primary index for the `docs/` folder.

---

## 1. Required Read Order for Every Task

Minimum required docs before any code or doc changes:
1. [AGENTS.md](../AGENTS.md)
2. [README.md](../README.md)
3. [SPECIFICATION.md](SPECIFICATION.md)
4. [DATAPACK_AUTHORING.md](DATAPACK_AUTHORING.md)
5. [COMPONENT_REFERENCE.md](COMPONENT_REFERENCE.md)
6. [CONDITION_REFERENCE.md](CONDITION_REFERENCE.md)
7. [ACTION_REFERENCE.md](ACTION_REFERENCE.md)
8. [SCOPE_MATRIX.md](SCOPE_MATRIX.md)
9. [VALIDATION_AND_ERROR_CODES.md](VALIDATION_AND_ERROR_CODES.md)
10. [PRESET_CATALOG.md](PRESET_CATALOG.md)
11. [WEB_AUTHORING_TOOL_SPEC.md](WEB_AUTHORING_TOOL_SPEC.md)

Read when relevant to scope changes:
1. [FUTURE_IDEAS.md](FUTURE_IDEAS.md) for post-v1 backlog promotions/reclassifications
2. [FUTURE_ADMIN_UI.md](FUTURE_ADMIN_UI.md) for deferred in-game/admin runtime UI promotions/reclassifications

Task execution rule:
- Each implementation task must explicitly reference the governing docs it used.
- Do not implement against stale docs; align docs before or with code changes.

---

## 2. Documentation Set Map

Core contracts:
- [SPECIFICATION.md](SPECIFICATION.md): Primary design and runtime behavior contract.
- [DATAPACK_AUTHORING.md](DATAPACK_AUTHORING.md): Canonical datapack shape and authoring contract.
- [WEB_AUTHORING_TOOL_SPEC.md](WEB_AUTHORING_TOOL_SPEC.md): Browser authoring/validation tool contract.
- [README.md](../README.md): Project summary and status.
- [AGENTS.md](../AGENTS.md): Contributor and coding-agent operating contract.

Shared reference docs:
- [COMPONENT_REFERENCE.md](COMPONENT_REFERENCE.md): Component IDs, schemas, status, and composition contracts.
- [CONDITION_REFERENCE.md](CONDITION_REFERENCE.md): Condition IDs, wrappers, and status contracts.
- [ACTION_REFERENCE.md](ACTION_REFERENCE.md): Action IDs, scope legality, and status contracts.
- [SCOPE_MATRIX.md](SCOPE_MATRIX.md): Canonical scope guarantees and legality matrix.
- [VALIDATION_AND_ERROR_CODES.md](VALIDATION_AND_ERROR_CODES.md): Stable diagnostics taxonomy.
- [PRESET_CATALOG.md](PRESET_CATALOG.md): Canonical preset/template catalog and status tags.

Deferred scope docs:
- [FUTURE_IDEAS.md](FUTURE_IDEAS.md): Non-normative backlog.
- [FUTURE_ADMIN_UI.md](FUTURE_ADMIN_UI.md): Deferred post-v1 in-game/admin runtime UI concept.

---

## 3. Cross-Update Matrix

When updating shared framework contracts (conditions/actions/scopes/status taxonomy):
- Update [SPECIFICATION.md](SPECIFICATION.md)
- Update [DATAPACK_AUTHORING.md](DATAPACK_AUTHORING.md)
- Update [CONDITION_REFERENCE.md](CONDITION_REFERENCE.md)
- Update [ACTION_REFERENCE.md](ACTION_REFERENCE.md)
- Update [SCOPE_MATRIX.md](SCOPE_MATRIX.md)
- Update [VALIDATION_AND_ERROR_CODES.md](VALIDATION_AND_ERROR_CODES.md)
- Update [WEB_AUTHORING_TOOL_SPEC.md](WEB_AUTHORING_TOOL_SPEC.md)
- Update [README.md](../README.md)
- Update [AGENTS.md](../AGENTS.md)

When updating component IDs/schemas/composition/runtime support:
- Update [COMPONENT_REFERENCE.md](COMPONENT_REFERENCE.md)
- Update [DATAPACK_AUTHORING.md](DATAPACK_AUTHORING.md)
- Update [SPECIFICATION.md](SPECIFICATION.md)
- Update [PRESET_CATALOG.md](PRESET_CATALOG.md) if preset composition guidance changes
- Update [WEB_AUTHORING_TOOL_SPEC.md](WEB_AUTHORING_TOOL_SPEC.md) if tooling behavior/labels change

When updating presets/templates:
- Update [PRESET_CATALOG.md](PRESET_CATALOG.md)
- Update [COMPONENT_REFERENCE.md](COMPONENT_REFERENCE.md), [CONDITION_REFERENCE.md](CONDITION_REFERENCE.md), and [ACTION_REFERENCE.md](ACTION_REFERENCE.md) if canonical mappings change
- Update [DATAPACK_AUTHORING.md](DATAPACK_AUTHORING.md) when examples or object-shape guidance changes

When promoting deferred scope into active scope:
- Update [SPECIFICATION.md](SPECIFICATION.md)
- Update [README.md](../README.md)
- Update [AGENTS.md](../AGENTS.md)
- Update [FUTURE_IDEAS.md](FUTURE_IDEAS.md) and/or [FUTURE_ADMIN_UI.md](FUTURE_ADMIN_UI.md)
- Update any impacted reference docs in the same change

---

## 4. Shared Reference Doc Format Standard

These files must stay aligned to a common structure and detail level:
- [COMPONENT_REFERENCE.md](COMPONENT_REFERENCE.md)
- [CONDITION_REFERENCE.md](CONDITION_REFERENCE.md)
- [ACTION_REFERENCE.md](ACTION_REFERENCE.md)
- [SCOPE_MATRIX.md](SCOPE_MATRIX.md)
- [VALIDATION_AND_ERROR_CODES.md](VALIDATION_AND_ERROR_CODES.md)
- [PRESET_CATALOG.md](PRESET_CATALOG.md)

Required format elements:
- title and one-line purpose summary
- metadata block (`Document status`, `Last updated`, `Scope`)
- governance/maintenance section with related-doc links
- canonical rules section(s)
- contributor/update rules section

Required detail level:
- explicit status taxonomy usage (`implemented`, `planned`, `reserved`, `deprecated`) where applicable
- concrete schema/shape notes for typed nodes where applicable
- scope legality and fail-closed behavior notes where applicable
- examples for canonical usage patterns

---

## 5. Linking and Path Rules

Inside `docs/`:
- Prefer sibling links (for example `[SPECIFICATION.md](SPECIFICATION.md)`).
- Link root docs with `../` (for example `[README.md](../README.md)` and `[AGENTS.md](../AGENTS.md)`).
- Avoid `docs/...` prefixes from inside `docs/` files.

At repository root:
- Link docs with `docs/...` paths.

---

## 6. Currency Checklist

Before merging:
1. Confirm all changed behavior/contracts are reflected in docs.
2. Confirm all cross-doc links resolve to existing files.
3. Confirm every touched doc updates its `Last updated` date when content changed.
4. Confirm reference docs remain format-aligned.
5. Confirm stale or orphan docs are removed or redirected.

